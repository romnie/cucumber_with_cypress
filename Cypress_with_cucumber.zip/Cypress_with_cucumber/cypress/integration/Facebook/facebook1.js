given('I visit the facebook login page', function () {
    cy.visit('https://www.facebook.com/');
});

when('the Facebook logo should be visible', function () {
    cy.wait(3000);
     cy.get('i[class="fb_logo img sp_RNXRBsVDn05 sx_43b207"]').should('be.visible');

});

Then(/^I enter my registration details with (.+) and (.+)$/, function (firstname, lastname, callback) {
    //const firstName="Sandra";
    //const lastName= "Extros";
    const email=firstname+"."+lastname +"@gmail.com";
    const pass= firstname+lastname+"123";
    cy.get('input[name="firstname"]').type(firstname);
    cy.get('input[name="lastname"]').type(lastname);
    cy.get('input[name="reg_email__"]').type(email);
    cy.get('input[name="reg_passwd__"]').type(pass);
    
});

Then ('I fill the registration form with incorrect details', function(){
    cy.get('input[name="firstname"]').type("");
    cy.get('input[name="lastname"]').type("");
    cy.get('input[name="reg_email__"]').type("");
    cy.get('input[name="reg_passwd__"]').type("");
})